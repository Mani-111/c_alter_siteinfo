<?php

namespace Drupal\c_alter_site_information\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\system\Form\SiteInformationForm;
use Drupal\node\Entity\Node;

class NodeDetail extends ControllerBase {
 
  /**
  * {@inheritdoc}
  */
	public function content_detail($siteapikey, $nid) {
		$sys_site_config = $this->config('system.site');
		$site_apikey = $sys_site_config->get('siteapikey');
		$node_exists = \Drupal::entityQuery('node')->condition('nid', $nid)->condition('type', 'page')->execute();
		if (!empty($siteapikey) && !empty($node_exists) && ($siteapikey == $site_apikey)) {
			$node = Node::load($nid);
			$data = \Drupal::service('serializer')->serialize($node, 'json');
			return array(
	      '#type' => 'markup',
	      '#markup' => $data,
	    );
		} else {
			return array(
	      '#type' => 'markup',
	      '#markup' => t('Access Denied'),
	    );
		}
	}
}